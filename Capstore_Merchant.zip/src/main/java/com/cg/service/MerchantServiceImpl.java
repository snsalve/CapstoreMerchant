package com.cg.service;

public class MerchantServiceImpl implements MerchantServiceInterface{

}
