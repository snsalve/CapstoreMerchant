package com.cg.repository;

import org.springframework.data.jpa.repository.JpaRepository;

import com.cg.entity.MerchantDetails;

public interface MerchantRepository extends JpaRepository<MerchantDetails, Integer>{

}
