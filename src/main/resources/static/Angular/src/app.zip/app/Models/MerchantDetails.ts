export class MerchantDetails{
    constructor(
	
	public phoneNumber:string,
	public alternatePhoneNumber:string,
	public alternateEmail:string,
	public isApproved:boolean,
	public rating:number
	
    ){}

}