export class ProductFeedback{
    constructor(
	
	public feedbackId:number,
	public feedbackSubject:string,
	public feedbackMessage:string
	
    ){}

}