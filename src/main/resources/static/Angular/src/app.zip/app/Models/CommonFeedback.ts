export class CommonFeedback{
    constructor(
	
	public feedbackId:number,
	public feedbackSubject:string,
	public feedbackMessage:string
	
    ){}

}