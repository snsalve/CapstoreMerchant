export class UserAddress{
    constructor(
	
	public addressId:number,
	public address_line1:string,
	public address_line2:string,
	public district:string,
	public state:string,
	public landmark:string,
	public pinCode:number
	
    ){}

}